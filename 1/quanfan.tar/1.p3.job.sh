#!/bin/bash
#SBATCH --job-name=fq1p3
#SBATCH --output=1-p3.txt
#SBATCH -N 1
#SBATCH -n 32
#SBATCH -t 5:00:00

./1-p3