#!/bin/bash
#SBATCH --job-name=fq2p3
#SBATCH --output=2-p3.txt
#SBATCH -N 1
#SBATCH -n 32
#SBATCH -t 5:00:00

./2-p3